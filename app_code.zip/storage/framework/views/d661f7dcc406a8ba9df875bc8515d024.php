<?php $__env->startSection('title', 'Laporan & Moderasi - Admin KerjaKampus'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="space-y-8">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 text-rose-700 text-xs font-bold uppercase tracking-wider mb-2">
                Pusat Moderasi & Keamanan
            </div>
            <h1 class="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">Laporan Aduan Pelanggaran</h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-1">Tinjau laporan dari pengguna terkait indikasi spam, penipuan, atau konten tidak patut.</p>
        </div>
        <div class="px-4 py-2 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center gap-2 self-start sm:self-center text-xs font-bold text-slate-700">
            Total Laporan: <?php echo e($reports->total()); ?>

        </div>
    </div>

    <?php if($reports->isEmpty()): ?>
        <div class="bg-white rounded-3xl border border-slate-200/80 p-16 text-center space-y-4 shadow-xs">
            <div class="w-20 h-20 rounded-3xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
                <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
            </div>
            <h3 class="text-xl font-black text-slate-900">Semua Laporan Telah Bersih</h3>
            <p class="text-xs sm:text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
                Tidak ada aduan pelanggaran baru yang membutuhkan tindakan saat ini. Platform berjalan tertib dan aman.
            </p>
        </div>
    <?php else: ?>
        <div class="space-y-4">
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                    $reportStatus = $report->status->value ?? $report->status;
                ?>
                <div class="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-7 shadow-xs hover:shadow-md transition-all space-y-4">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div class="flex items-center gap-2 flex-wrap">
                            <span class="px-3 py-1 text-xs font-black rounded-xl uppercase bg-rose-50 text-rose-700 border border-rose-200/60">
                                Target: <?php echo e(ucfirst($report->target_type)); ?> #<?php echo e($report->target_id); ?>

                            </span>
                            <span class="px-3 py-1 text-xs font-black rounded-xl uppercase tracking-wider <?php echo e($reportStatus === 'pending' ? 'bg-amber-50 text-amber-700 border border-amber-200/60' : 'bg-slate-100 text-slate-600'); ?>">
                                <?php echo e(ucfirst($reportStatus)); ?>

                            </span>
                        </div>
                        <span class="text-xs text-slate-400 font-medium">Dilaporkan <?php echo e($report->created_at->diffForHumans()); ?></span>
                    </div>

                    <div class="space-y-1">
                        <h4 class="font-black text-slate-900 text-base">Alasan: <?php echo e($report->reason); ?></h4>
                        <p class="text-xs text-slate-500">
                            Pelapor: <span class="font-bold text-slate-800"><?php echo e($report->reporter?->name); ?></span> (<?php echo e($report->reporter?->email); ?>)
                        </p>
                    </div>

                    <?php if($report->description): ?>
                        <div class="p-4 bg-slate-50 rounded-2xl border border-slate-100 text-xs sm:text-sm text-slate-700 leading-relaxed">
                            <span class="font-bold block text-slate-900 mb-1 text-xs uppercase tracking-wider">Keterangan Tambahan:</span>
                            <?php echo e($report->description); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($reportStatus === 'pending'): ?>
                        <div class="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                            <form action="<?php echo e(route('admin.reports.dismiss', $report->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl border border-slate-200 transition-colors">
                                    Abaikan Laporan
                                </button>
                            </form>

                            <form action="<?php echo e(route('admin.reports.resolve', $report->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-colors">
                                    Tandai Selesai / Ditindak
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="mt-8">
                <?php echo e($reports->links()); ?>

            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\CODEATHOME_PKL\KERJAKAMPUS\resources\views/admin/reports.blade.php ENDPATH**/ ?>