<?php $__env->startSection('title', 'Notifikasi - KerjaKampus'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="space-y-6">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 class="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">Pusat Notifikasi</h1>
            <p class="text-xs sm:text-sm text-slate-500 mt-1">Pemberitahuan terkini terkait lamaran, status proyek, dan aktivitas akun Anda.</p>
        </div>

        <?php if($notifications->isNotEmpty()): ?>
            <form action="<?php echo e(route('notifications.read-all')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="text-xs font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-4 py-2.5 rounded-xl border border-indigo-100 transition-colors">
                    Tandai Semua Dibaca
                </button>
            </form>
        <?php endif; ?>
    </div>

    <?php if($notifications->isEmpty()): ?>
        <div class="bg-white rounded-3xl border border-slate-200/80 p-12 sm:p-16 text-center space-y-3 shadow-xs">
            <div class="w-16 h-16 rounded-3xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
            </div>
            <h3 class="text-lg font-bold text-slate-900">Belum Ada Notifikasi</h3>
            <p class="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto">Pemberitahuan penting akan ditampilkan di sini secara berkala.</p>
        </div>
    <?php else: ?>
        <div class="space-y-3">
            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-4 sm:p-5 rounded-2xl border transition-all flex items-start justify-between gap-4 <?php echo e(is_null($notif->read_at) ? 'bg-indigo-50/40 border-indigo-200/80 shadow-xs' : 'bg-white border-slate-200/80'); ?>">
                    <div class="flex items-start gap-3.5">
                        <div class="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 <?php echo e(is_null($notif->read_at) ? 'bg-gradient-to-tr from-indigo-600 to-violet-600 text-white shadow-xs' : 'bg-slate-100 text-slate-400'); ?>">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
                        </div>
                        <div class="space-y-1">
                            <div class="flex items-center gap-2">
                                <h4 class="font-bold text-xs sm:text-sm text-slate-900 <?php echo e(is_null($notif->read_at) ? 'text-indigo-950' : ''); ?>"><?php echo e($notif->title); ?></h4>
                                <?php if(is_null($notif->read_at)): ?>
                                    <span class="w-2 h-2 rounded-full bg-indigo-600"></span>
                                <?php endif; ?>
                            </div>
                            <p class="text-xs text-slate-600 leading-relaxed"><?php echo e($notif->message); ?></p>
                            <span class="text-[10px] text-slate-400 font-medium block"><?php echo e($notif->created_at->diffForHumans()); ?></span>
                        </div>
                    </div>

                    <?php if(is_null($notif->read_at)): ?>
                        <form action="<?php echo e(route('notifications.read', $notif->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="text-xs font-bold text-indigo-600 hover:text-indigo-800 shrink-0 px-2 py-1 rounded-md hover:bg-indigo-50 transition-colors">
                                Tandai dibaca
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="mt-6">
                <?php echo e($notifications->links()); ?>

            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\CODEATHOME_PKL\KERJAKAMPUS\resources\views/notifications/index.blade.php ENDPATH**/ ?>