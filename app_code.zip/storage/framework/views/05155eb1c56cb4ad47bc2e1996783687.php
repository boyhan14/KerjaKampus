<?php
/** @var \Laravel\Boost\Install\GuidelineAssist $assist */
?>
___SCOPED_START_WyJ0ZXN0c1wvKioiXQ==___
# PHPUnit

- This project uses PHPUnit. Create tests with ___SINGLE_BACKTICK___<?php echo e($assist->artisanCommand('make:test --phpunit {name}')); ?>___SINGLE_BACKTICK___.
- Do not include the test suite directory in ___SINGLE_BACKTICK___{name}___SINGLE_BACKTICK___. Use ___SINGLE_BACKTICK___SomeFeatureTest___SINGLE_BACKTICK___, not ___SINGLE_BACKTICK___Feature/SomeFeatureTest___SINGLE_BACKTICK___.
- Read the ___SINGLE_BACKTICK___testing-best-practices___SINGLE_BACKTICK___ skill for guidance on coverage, naming, structure, dependency isolation, and review.

## Running Tests

- Run the narrowest set of tests that covers the change. Pass a file path or ___SINGLE_BACKTICK___--filter=testName___SINGLE_BACKTICK___ to ___SINGLE_BACKTICK___<?php echo e($assist->artisanCommand('test --compact')); ?>___SINGLE_BACKTICK___.
- Rerun a test after each change to it.
- Run ___SINGLE_BACKTICK___<?php echo e($assist->binCommand('phpunit')); ?>___SINGLE_BACKTICK___ to call the test runner directly. It accepts the same file path and ___SINGLE_BACKTICK___--filter=testName___SINGLE_BACKTICK___ arguments.
___SCOPED_END___
<?php /**PATH D:\CODEATHOME_PKL\KERJAKAMPUS\storage\framework\views/8cdf590822423b871bed5be8c4a6ec59.blade.php ENDPATH**/ ?>