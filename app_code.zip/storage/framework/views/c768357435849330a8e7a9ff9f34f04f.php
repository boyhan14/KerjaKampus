<?php $__env->startSection('title', 'Profil Saya - KerjaKampus'); ?>

<?php $__env->startSection('dashboard-content'); ?>
<div class="space-y-8">
    <!-- Header Card -->
    <div class="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-xs">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div class="flex items-center gap-5">
                <!-- Avatar -->
                <div class="relative group shrink-0">
                    <div class="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-tr from-indigo-600 via-indigo-600 to-violet-600 text-white font-black text-2xl sm:text-3xl flex items-center justify-center uppercase overflow-hidden shadow-md shadow-indigo-500/15">
                        <?php if($user->avatar): ?>
                            <img src="<?php echo e(asset('storage/' . $user->avatar)); ?>" alt="<?php echo e($user->name); ?>" class="w-full h-full object-cover">
                        <?php else: ?>
                            <?php echo e(substr($user->name, 0, 1)); ?>

                        <?php endif; ?>
                    </div>
                </div>

                <div class="space-y-1 min-w-0">
                    <div class="flex flex-wrap items-center gap-2">
                        <h1 class="text-xl sm:text-2xl font-black text-slate-900 tracking-tight"><?php echo e($user->name); ?></h1>
                        <span class="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100 uppercase">
                            <?php echo e($user->role?->value ?? $user->role); ?>

                        </span>
                    </div>
                    <p class="text-xs sm:text-sm text-slate-500">
                        <?php echo e('@' . ($user->username ?? 'user')); ?> &bull; <?php echo e($user->location ?? 'Indonesia'); ?>

                    </p>
                    <p class="text-xs text-slate-400">Bergabung <?php echo e($user->created_at->format('M Y')); ?></p>
                </div>
            </div>

            <div class="flex items-center gap-3 shrink-0">
                <?php if($user->username): ?>
                    <a href="<?php echo e(route('talents.show', $user->username)); ?>" target="_blank" class="px-4 py-2.5 text-xs font-bold rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors">
                        Lihat Publik &rarr;
                    </a>
                <?php endif; ?>
                <a href="<?php echo e(route('profile.edit')); ?>" class="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all btn-press">
                    Edit Profil
                </a>
            </div>
        </div>

        <!-- Completion bar if talent -->
        <?php if($user->isTalent()): ?>
            <div class="mt-6 pt-6 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div class="space-y-1.5 w-full max-w-md">
                    <div class="flex items-center justify-between text-xs font-bold">
                        <span class="text-slate-600">Kelengkapan Profil</span>
                        <span class="text-indigo-600"><?php echo e($completion); ?>%</span>
                    </div>
                    <div class="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                        <div class="bg-gradient-to-r from-indigo-500 to-violet-600 h-2 rounded-full transition-all duration-500" style="width: <?php echo e($completion); ?>%"></div>
                    </div>
                </div>
                <span class="text-xs text-slate-400">Profil lengkap meningkatkan 3x peluang diterima!</span>
            </div>
        <?php endif; ?>
    </div>

    <!-- Bio & Details Grid -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <!-- Main details -->
        <div class="md:col-span-2 space-y-6">
            <!-- Bio -->
            <div class="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-xs space-y-3">
                <h3 class="font-bold text-slate-900 text-sm">Tentang Saya</h3>
                <p class="text-xs sm:text-sm text-slate-600 leading-relaxed whitespace-pre-line">
                    <?php echo e($user->bio ?? 'Belum ada biodata yang ditambahkan. Klik tombol Edit Profil di atas untuk menceritakan tentang diri dan pengalaman profesionalmu.'); ?>

                </p>
            </div>

            <!-- Skills -->
            <div class="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-xs space-y-4">
                <div class="flex items-center justify-between">
                    <h3 class="font-bold text-slate-900 text-sm">Keahlian (Skills)</h3>
                    <a href="<?php echo e(route('skills.index')); ?>" class="text-xs font-bold text-indigo-600 hover:underline">Kelola Keahlian &rarr;</a>
                </div>

                <div class="flex flex-wrap gap-2">
                    <?php $__empty_1 = true; $__currentLoopData = $user->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <span class="px-3 py-1.5 rounded-xl bg-slate-50 text-slate-700 border border-slate-200/60 text-xs font-semibold">
                            <?php echo e($skill->name); ?>

                        </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="text-xs text-slate-400">Belum ada keahlian yang ditambahkan.</span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Portfolio summary -->
            <div class="bg-white rounded-3xl border border-slate-200/80 p-6 sm:p-8 shadow-xs space-y-4">
                <div class="flex items-center justify-between">
                    <h3 class="font-bold text-slate-900 text-sm">Portofolio Teratas</h3>
                    <a href="<?php echo e(route('portfolio.index')); ?>" class="text-xs font-bold text-indigo-600 hover:underline">Semua Portofolio &rarr;</a>
                </div>

                <?php if($user->portfolioItems->isEmpty()): ?>
                    <p class="text-xs text-slate-400">Belum ada karya portofolio yang ditambahkan.</p>
                <?php else: ?>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <?php $__currentLoopData = $user->portfolioItems->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="p-3.5 rounded-2xl border border-slate-100 bg-slate-50/50 flex items-center justify-between">
                                <span class="text-xs font-bold text-slate-900 truncate"><?php echo e($item->title); ?></span>
                                <a href="<?php echo e(route('portfolio.show', $item->slug)); ?>" class="text-xs text-indigo-600 font-bold shrink-0 hover:underline">Buka &rarr;</a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar Info -->
        <div class="space-y-6">
            <div class="bg-white rounded-3xl border border-slate-200/80 p-6 shadow-xs space-y-4">
                <h3 class="font-bold text-slate-400 text-xs uppercase tracking-wider">Informasi Kontak & Akun</h3>
                
                <div class="space-y-3.5 text-xs">
                    <div>
                        <span class="text-slate-400 block mb-0.5">Alamat Email</span>
                        <span class="font-bold text-slate-800"><?php echo e($user->email); ?></span>
                    </div>

                    <?php if($user->phone): ?>
                        <div>
                            <span class="text-slate-400 block mb-0.5">Nomor Telepon</span>
                            <span class="font-bold text-slate-800"><?php echo e($user->phone); ?></span>
                        </div>
                    <?php endif; ?>

                    <?php if($user->education): ?>
                        <div>
                            <span class="text-slate-400 block mb-0.5">Pendidikan / Kampus</span>
                            <span class="font-bold text-slate-800"><?php echo e($user->education); ?></span>
                        </div>
                    <?php endif; ?>

                    <?php if($user->experience_years): ?>
                        <div>
                            <span class="text-slate-400 block mb-0.5">Pengalaman Kerja</span>
                            <span class="font-bold text-slate-800"><?php echo e($user->experience_years); ?> Tahun</span>
                        </div>
                    <?php endif; ?>

                    <?php if($user->website): ?>
                        <div>
                            <span class="text-slate-400 block mb-0.5">Website</span>
                            <a href="<?php echo e($user->website); ?>" target="_blank" rel="noopener" class="font-bold text-indigo-600 hover:underline truncate block"><?php echo e($user->website); ?></a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Social links -->
                <div class="pt-4 border-t border-slate-100 space-y-2">
                    <span class="text-slate-400 block text-xs">Media Sosial</span>
                    <div class="flex items-center gap-3">
                        <?php if($user->github_url): ?>
                            <a href="<?php echo e($user->github_url); ?>" target="_blank" rel="noopener" class="text-slate-500 hover:text-slate-900 text-xs font-bold">GitHub</a>
                        <?php endif; ?>
                        <?php if($user->linkedin_url): ?>
                            <a href="<?php echo e($user->linkedin_url); ?>" target="_blank" rel="noopener" class="text-slate-500 hover:text-indigo-600 text-xs font-bold">LinkedIn</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\CODEATHOME_PKL\KERJAKAMPUS\resources\views/profile/show.blade.php ENDPATH**/ ?>