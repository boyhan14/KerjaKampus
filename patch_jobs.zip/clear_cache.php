<?php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
Illuminate\Support\Facades\Cache::flush();
echo "<h2 style='color:green;font-family:sans-serif;'>✅ Cache berhasil dibersihkan total!</h2><p><a href='/jobs' style='font-size:18px;font-family:sans-serif;'>👉 Klik di sini untuk membuka halaman Lowongan (/jobs)</a></p>";
